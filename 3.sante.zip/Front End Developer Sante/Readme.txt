Problem Statement:
	Make a Shopping site page
	Technological stack
		1. HTML/HTML5
		2. CSS/CSS3
		3. Javascript 
		4. UI (bootstrap) 
	How to run 
		1. Run the index.html to get the page 
		2. Restaurant marked in the google map 
		3. Clean & intuitive design